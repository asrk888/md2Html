
# MailChimp Markdown to Html  parser 

MailChimp Markdown to Html parser is an intelligent tool data which converts the
Markdown format to Html format data.
It creates the Html file with converted html data in batch and console interactive mode.
Also, it has Rest Api to get the markdown data in request body and the converted html data will be sent be in the response body.
Types of Mode:
Batch Mode: Scan for markdown file in lookup folder and converted it into html file.
Interactive Mode: User can provide the markdown file in the console. it will be converted into html file.
Rest API: User can invoke webservice to convert markdown file data to html data

Version: 1.0

## Tech Stack

**Software:** Golang

## Run Locally

Unzip the project
  Unzip mailChimpMd2HtmlParser.zip file

Go to the project directory - cd <your project directory>

Run the exe mailChimpMd2HtmlParser

## Configuration 

Configurations are given in the mcConfig.json file and its placed in config directory 
under project directory.


## Features

- Batch Mode : Scan for markdown file in lookup folder
- Interactive Mode: User can provide the markdown file in the command prompt
- Rest API: User can invoke webservice to convert markdown data to html data

## API Reference

#### Converts the markdown file data in body into html data 

  GET http://localhost:8987/api/mcmd2html/v1



