package main

import "testing"

type htmlTest struct {
	inputMarkdown, expectedhtml string
}

var htmlTests = []htmlTest{
	{"`###### Heading 6`", "`<h6>Heading 6</h6>`\n"},
	{"`Unformatted text`", "`<p>Unformatted text</p>`\n"},
	{"`[Link text](https://www.example.com)`", "`<a href=\"https://www.example.com\">Link text</a>`\n"},
}

func TestMarkdownToHtml(t *testing.T) {
	//markdownData := mdToHtmlParsing()
	for _, test := range htmlTests {
		if output := mdToHtmlParsing(test.inputMarkdown); output != test.expectedhtml {
			t.Errorf("Output %q not equal to expected %q", output, test.expectedhtml)
		}
	}
}

func BenchmarkAdd(b *testing.B) {
	for i := 0; i < b.N; i++ {
		mdToHtmlParsing("`###### Heading 6`")
	}
}
