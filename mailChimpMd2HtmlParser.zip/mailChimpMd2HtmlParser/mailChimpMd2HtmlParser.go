package main

/*MailChimp Markdown to Html parser is an intelligent tool data which converts the
Markdown format to Html format data.
It creates the Html file with converted html data in batch and console interactive mode.
Also it has Rest Api to get the markdown data in request body and the converted html data will be sent be
in the response body.

Batch Mode : Scan for markdown file in lookup folder and converted it into html file.
Interactive Mode: User can provide the markdown file in the console. it will be converted into html file.
Rest API: User can invoke webservice to convert markdown file data to html data

Version: 1.0
*/

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"
)

//****************************** User defined structures ******************************//

//Configuration JSON file data fields
type configStruct struct {
	HttpHost     string `json:"httpHost"`
	HttpPort     string `json:"httpPort"`
	OutExtension string `json:"outExtension"`
	Version      string `json:"version"`
	FileDir      string `json:"fileDir"`
	LogFile      string `json:"logFile"`
	LookupFile   string `json:"lookupFile"`
	EndpointUrl  string `json:"endpointUrl"`
}

//****************************** Constants *******************************************//
const (
	configFileName string = "config/mcConfig.json"
	blankValue     string = ""
	colon          string = ":"
	CmdPrefix      string = "/"
)

//*********************************** Local variables *************************************//
var (
	configData         configStruct
	hyperlinkTagRegExp *regexp.Regexp
	paraTagRegExp      *regexp.Regexp
	headerTagRegExp    *regexp.Regexp
	blanklineRegExp    *regexp.Regexp
)

//************************************* Initialization *************************************//

func init() {
	//Regular expression for converting markdown file record to <a> hyberlink tag
	hyperlinkTagRegExp = regexp.MustCompile(`\[(.*?)]\((.*?)\)`)
	//Regular expression for converting markdown file record to <p> para tag
	paraTagRegExp = regexp.MustCompile("^(`?)( *[0-9A-Za-z_]+)(.*[^`])(`?$)")
	////Regular expression for converting markdown file record to <h> header tag
	headerTagRegExp = regexp.MustCompile("^(`?)(#+ )(.*[^`])(`?$)")
	//Regular expression for converting markdown blanck line record to ignored
	blanklineRegExp = regexp.MustCompile("^(`?)(?i)<p>blank line</p>(`?$)")
}

//************************************ Helper Functions *************************************//

//It creates the HTML file with same markdown file name and datatime. Place the html file
//in same markdown file directory. This Helper fuction will be called from batch/incteractive mode.
func createHtmlFile(htmlData string, fileName string) {
	//After Conversion create the html file with same name and datetime
	fileTime := time.Now().Format("20060102150405")
	fileNm, _, _ := strings.Cut(fileName, ".")
	outHtmlFile := fileNm + "_" + fileTime + configData.OutExtension
	err := ioutil.WriteFile(outHtmlFile, []byte(htmlData), 0)
	if err != nil {
		// Rename the Error out markdown file to err file
		log.Println("output File err ", err)
		err = os.Rename(fileName, fileName+"_err")
		if err != nil {
			log.Println("Input File rename err ", err)
		}
	} else {
		// Rename the Processed markdown file to done file
		log.Println("Markdown file successfully parsed refer output file ", outHtmlFile)
		err = os.Rename(fileName, fileName+"_done")
		if err != nil {
			log.Println("Input File rename err ", err)
		}
	}
}

//************************************* Local Functions *************************************//

//Fuction loads configuration details from mcConfig.json file.
func loadConfigFile() (err error) {
	configFile, err := os.Open(configFileName)
	if err != nil {
		return
	} else {
		defer configFile.Close()
	}
	jsonParser := json.NewDecoder(configFile)
	err = jsonParser.Decode(&configData)
	if err != nil {
		return
	}
	return
}

//Function rename old log file and create new log file. Set log file
func createLogFile() (err error) {
	//rename and backup the old log file
	if _, err := os.Stat(configData.LogFile); err == nil {
		bkpTime := time.Now().Format("20060102150405")
		os.Rename(configData.LogFile, configData.LogFile+bkpTime)
	}
	logFilePtr, err := os.Create(configData.LogFile)
	if err == nil {
		// set the log output
		log.SetOutput(logFilePtr)
	}
	return
}

//Fuction converts the markdown format data into Htmlformat data in string variable
func mdToHtmlParsing(inputTxt string) (ouputTxt string) {
	//Set scanner to read the data from input string variable
	scanner := bufio.NewScanner(strings.NewReader(inputTxt))
	//Read line by line from the input string
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		//Check whether the current line has header tag data by using header regular expression
		if headerTagRegExp.MatchString(line) {
			//get header size by counting the #
			cnt := strings.Count(strings.TrimLeft(strings.TrimSpace(line), " "), "#")
			cntstr := strconv.Itoa(cnt)
			replstr := "$1<h" + cntstr + ">$3</h" + cntstr + ">$4"
			line = headerTagRegExp.ReplaceAllString(line, replstr)
		}
		//Check whether the current line has para tag data by using para regular expression
		if paraTagRegExp.MatchString(line) {
			line = paraTagRegExp.ReplaceAllString(line, "$1<p>$2$3</p>$4")
		}
		//Check whether the current line has hyperlink tag data by using hyperlink regular expression
		if hyperlinkTagRegExp.MatchString(line) {
			line = hyperlinkTagRegExp.ReplaceAllString(line, "<a href=\"$2\">$1</a>")
		}
		if blanklineRegExp.MatchString(line) {
			line = blanklineRegExp.ReplaceAllString(line, "${1}Ignored$2")
		}
		//Appending th output html data
		ouputTxt = ouputTxt + line + "\n"
	}
	return
}

//Fuction runs in background and scan for the markdown file(*.md) in lookup folder. if markdown file is placed then
//it Converts into html file data and place html file in the same folder.
func batchFileProcessing(syncCh chan string, batchSignalCh chan bool, wg *sync.WaitGroup) {
	log.Printf("MailChimp Markdown to Html Parser %s Running and looking input file in  %s\n", configData.Version, configData.FileDir+configData.LookupFile)
	fmt.Printf("MailChimp Markdown to Html Parser %s Running and looking input file in %s\n", configData.Version, configData.FileDir+configData.LookupFile)
	<-syncCh
	for {
		select {
		case <-batchSignalCh:
			fmt.Println("User Requested to Quit : Batch processing stopped")
			wg.Done()
			return
			//break
		default:
			//continue
			// continuously scan for markdown file(*.md) in lookup folder
			files, err := filepath.Glob(configData.FileDir + configData.LookupFile)
			if err != nil {
				time.Sleep(1 * time.Minute)
				continue
			}
			//if File found then data will be read into string variable
			for _, fileName := range files {
				fileData, err := ioutil.ReadFile(fileName)
				if err != nil {
					log.Println("input File err ", err)
					continue
				}
				log.Println("Processing file name", fileName)
				//Calls mdToHtmlParsing function to convert from markdown file to Html file
				htmlData := mdToHtmlParsing(string(fileData))
				//fmt.Println(htmlData)
				//Create html file with converted html data
				createHtmlFile(htmlData, fileName)
			}
		}

	}
}

//Fuction runs in background and prompts user to enter markdown file. then
//it Converts into html file data and place html file in the same user entered folder.
func interactiveFileProcessing(syncCh chan string, batchSignalCh chan bool, apiSignalCh chan bool, wg *sync.WaitGroup) {
	<-syncCh
	scanner := bufio.NewScanner(os.Stdin)
	for {
		// continuously prompts user to provide the  markdown file(*.md)
		fmt.Println("")
		fmt.Printf("Enter the markdown file with path or <Quit>: ")
		if scanner.Scan() {
			userInput := scanner.Text()
			fileName := userInput
			if strings.ToLower(strings.TrimSpace(userInput)) == "quit" {
				batchSignalCh <- true
				apiSignalCh <- true
				fmt.Println("User Requested to Quit : Interactive processing stopped")
				wg.Done()
				return
			} else if strings.TrimSpace(userInput) == "" {
				continue
			}
			//If user entered file and File found then data will be read into string variable
			fileData, err := ioutil.ReadFile(fileName)
			if err != nil {
				fmt.Println("input File err ", err)
				continue
			}
			log.Println("Processing file name", fileName)
			htmlData := mdToHtmlParsing(string(fileData))
			fmt.Println(htmlData)
			//Create html file with converted html data
			createHtmlFile(htmlData, fileName)
		}
	}
}

//Function runs in background to shutdown the server gracefully when user requested to stop
func serverShutdown(ctx context.Context, apiSignalCh chan bool, httpServer *http.Server) {
	if <-apiSignalCh {
		fmt.Println("User Requested to Quit : Api processing stopped")
		httpServer.Shutdown(ctx)
		return
	}
}

//Fuction runs in background and scan for the markdown file(*.md) in lookup folder. if markdown file is placed then
//it Converts into html file data and place html file in the same folder.
func apiHttpRequestProcessing(wg *sync.WaitGroup, syncCh chan string, apiSignalCh chan bool) {
	log.Printf("MailChimp Markdown to Html Parser api Server %s Running on  %s\n", configData.Version, configData.HttpHost+colon+configData.HttpPort+configData.EndpointUrl)
	fmt.Printf("MailChimp Markdown to Html Parser api Server %s Running on  %s\n", configData.Version, configData.HttpHost+colon+configData.HttpPort+configData.EndpointUrl)
	<-syncCh

	httpServer := &http.Server{
		Addr:    configData.HttpHost + colon + configData.HttpPort,
		Handler: http.HandlerFunc(apiHandler),
	}
	ctx := context.Background()
	go serverShutdown(ctx, apiSignalCh, httpServer)
	//http.HandleFunc(configData.EndpointUrl, apiHandler)
	err := httpServer.ListenAndServe()
	//err := http.ListenAndServe(configData.HttpHost+colon+configData.HttpPort, nil)
	if err != nil {
		log.Println("http server error :", err)
		wg.Done()
		return
	}
}

//************************************** Handlers **************************************
//Function to handle rest api http request and response- http://localhost:8987/api/mcmd2html/v1
//Input-  http Resquest (GET Method); markdown file format data in get request body
//Output- http response html file format data in response body
func apiHandler(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case "GET":
		markdownData, err := ioutil.ReadAll(r.Body)
		if err != nil {
			log.Fatal(err)
		}
		htmlData := mdToHtmlParsing(string(markdownData))
		//fmt.Println(htmlData)
		w.Write([]byte(htmlData))
	default:
		w.WriteHeader(http.StatusNotImplemented)
		w.Write([]byte(http.StatusText(http.StatusNotImplemented)))
	}
}

//************************************* Main Function *************************************//
//MailChimp(MC) Markdown file to Html parser execution starts here - Main function
func main() {
	//Load Configuration file
	err := loadConfigFile()
	if err != nil {
		log.Println("mcConfig.json configuration file load error :", err.Error())
		os.Exit(1)
	}
	//Create Log File
	err = createLogFile()
	if err != nil {
		log.Println(err)
	}
	log.Println("MailChimp Markdown to Html Parser ", configData.Version, " Started execution @ ", time.Now())
	fmt.Println("MailChimp Markdown to Html Parser ", configData.Version, " Started execution @ ", time.Now())
	fmt.Println()
	//
	var wg sync.WaitGroup
	batchSignalCh := make(chan bool)
	apiSignalCh := make(chan bool)
	syncCh := make(chan string, 1)
	syncCh <- "Initiated"
	//Batch markdown file conversion to html
	wg.Add(1)
	go batchFileProcessing(syncCh, batchSignalCh, &wg)
	syncCh <- "Initiated"
	wg.Add(1)
	//Non blocking Http's Server execution
	go apiHttpRequestProcessing(&wg, syncCh, apiSignalCh)
	syncCh <- "Initiated"
	wg.Add(1)
	//User interactive markdown file conversion to html
	go interactiveFileProcessing(syncCh, batchSignalCh, apiSignalCh, &wg)
	wg.Wait()
	close(apiSignalCh)
	close(batchSignalCh)
	close(syncCh)
}
